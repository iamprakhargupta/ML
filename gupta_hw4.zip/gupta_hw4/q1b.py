"""
FileName: q1a.py
Author: prakhar gupta_hw4 pg9349
Description: Create a multinomial MLP model for XOR
"""


import matplotlib.pyplot as plt
import os
import numpy as np
import pandas as pd
from helper_functions import *

"""
0.004443493661832224
"""

beta = 0# regularization coefficient
alpha = 0.001 # step size coefficient
n_epoch = 50000 # number of epochs (full passes through the dataset)
eps =  0.00000# controls convergence criterion

# begin simulation

path = os.getcwd() + '/spiral_train.dat'
data2 = pd.read_csv(path, header=None)
X=data2.to_numpy()

cols = data2.shape[1]
X2 = data2.iloc[:,0:-1]
y2 = data2.iloc[:,-1]
y3=y2.values
y3=np.vstack(y3)
y2=pd.get_dummies(y2)
np.random.seed(1)
# convert to numpy arrays and initalize the parameter array theta
X2 = np.array(X2.values)
y2 = np.array(y2.values)

# # Uncomment for zero intialization
# w = np.zeros((X2.shape[1],y2.shape[1]))


instances = X2.shape[0]
attributes = X2.shape[1]
hidden_nodes = 4
output_labels = 3

w1 = np.random.rand(attributes,hidden_nodes)
b1 = np.random.randn(hidden_nodes)

w2 = np.random.rand(hidden_nodes,output_labels)
b2 = np.random.randn(output_labels)

theta2 = (b1, w1,b2,w2)

L = computeCost(X2, y2, theta2, beta)

# print(X2)
# print(w1)
# print("_________")
# print(w2)




halt = np.inf # halting variable (you can use these to terminate the loop if you have converged)
print("-1 L = {0}".format(L))

i = 0
cost=[]
cost.append(L)
while(i < n_epoch):
	dcost_bh, dcost_wh,dcost_bo,dcost_wo = computeGrad(X2, y2, theta2, beta)
	b1 = theta2[0]
	w1 = theta2[1]
	b2 = theta2[2]
	w2 = theta2[3]



	# print(dcost_b1)
    ############################################################################
	# update rules go here...
	# WRITEME: write your code here to perform a step of gradient descent & record anything else desired for later
    ############################################################################
	b1 -= alpha*dcost_bh
	w1 -= alpha*dcost_wh
	b2 -= alpha*dcost_bo
	w2 -= alpha*dcost_wo



	theta2 = (b1, w1,b2,w2)
	# print(w2)
	L = computeCost(X2, y2, theta2, beta)
	# print(w)
    ############################################################################
	# WRITEME: write code to perform a check for convergence (or simply to halt early)
    ############################################################################
	cost.append(L)
	if len(cost)>=2:
		halt = cost[-2]-cost[-1]
		# print(halt)

	print(" {0} L = {1}".format(i,L))
	i += 1
# print parameter values found after the search

# print("w = ",w)
# print("b = ",b)
halt = cost[-2]-cost[-1]
if  halt <=eps:
	print("Model initial epochs set at ",n_epoch)
	print("Convergence happened at epoch ",i-1)
############################################################################
predictions = predict(X2, theta2)
# print(predictions)
# print(predictions)
# WRITEME: write your code here calculate your actual classification error (using the "predictions" variable)
y3=np.argmax(y2,axis=1)
N = predictions.shape[0]
y=predictions

print("-------")
# print(predictions)
accuracy = (y3 == y).sum() / N
print('Accuracy = {0}%'.format(accuracy * 100.))
err = 1-accuracy
print ('Error = {0}%'.format(err * 100.))


plt.plot(cost, label='Training Loss')
plt.title("LOSS CURVE")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend(loc="upper right")
plt.savefig("Losscurveq1b.jpeg")
plt.show()


h = 0.001
cmap='RdBu'

x_min, x_max = X2[:,0].min() - 100*h, X2[:,0].max() + 100*h
y_min, y_max = X2[:,1].min() - 100*h, X2[:,1].max() + 100*h
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))

# print(np.c_[xx.ravel(), yy.ravel()])
Z = predict(np.c_[xx.ravel(), yy.ravel()],theta2)
Z = Z.reshape(xx.shape)

plt.figure(figsize=(7,7))
plt.contourf(xx, yy, Z, cmap=cmap, alpha=0.9)
plt.contour(xx, yy, Z, colors='k', linewidths=1)
plt.scatter(X[:,0], X[:,1], c=y, cmap=cmap, edgecolors='k');
plt.title("Spiral data with decision boundary")
plt.savefig("decision_boundaryq1b.png")
plt.show()
