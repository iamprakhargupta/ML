"""
FileName: helperfunctions.py
Author: prakhar gupta_hw4 pg9349
Description: functions to train models for part 1a,1b,1c
"""
import matplotlib.pyplot as plt
import os
import numpy as np
import pandas as pd




def softmax(z):
    ############################################################################
	# WRITEME: write your code here to complete the routine
	# print(np.sum(np.exp(z),axis=1))
	# print(np.exp(z))
	denom=np.sum(np.exp(z), axis=1)
	# print(denom.shape)
	denom=np.reshape(denom,(denom.shape[0],1))
	# print(denom)
	return np.exp(z) / denom


def predict(X, theta):
    ############################################################################
	# WRITEME: write your code here to complete the routine
	p,_=regress(X,theta)
	# return p
	# print(p)
	return np.argmax(p,axis=1)
    # ############################################################################


def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_der(x):
    return sigmoid(x) *(1-sigmoid (x))

def dRelu(x):
    x[x<=0] = 0
    x[x>0] = 1
    return x


def Relu(Z):
    return np.maximum(0,Z)

def regress(X, theta):
    ############################################################################
	# WRITEME: write your code here to complete the routine
	b1, w1, b2, w2 = theta
	zh = np.dot(X, w1) + b1
	a1 = sigmoid(zh)
	z2 = np.dot(a1, w2) + b2
	a2 = softmax(z2)

	return a2,a1


def log_likelihood(p, y):
    ############################################################################
	# WRITEME: write your code here to complete the routine
	size=y.shape[0]
	loss = np.sum(np.multiply(y, np.log(p)))
	log_loss = -1*np.sum(loss) / size
	return log_loss

def computeCost(X, y, theta, beta): ## loss is now Bernoulli cross-entropy/log likelihood
    ############################################################################
	# WRITEME: write your code here to complete the routine
	p, ah = regress(X, theta)
	# size = X.shape[0]
	b1, w1,b2,w2  = theta

	reg= beta*(np.sum(w1**2)+np.sum(w2**2	))/2


	loss=log_likelihood(p,y)

	# loss = -np.sum(y * np.log(ao))
	return loss+reg


def computeGrad(X, y, theta, beta):
    ############################################################################
	# WRITEME: write your code here to complete the routine (
	# NOTE: you do not have to use the partial derivative symbols below, they are there to guide your thinking)

	b1, w1, b2, w2 = theta
	ao, ah = regress(X, theta)
	zh = np.dot(X, w1) + b1
	loss = ao - y
	db2 = np.sum(loss,axis=0)
	dw2 = np.dot(ah.T, loss) + (beta * w2)
	dh1 = np.dot(loss, w2.T)
	dz1 = sigmoid_der(zh)
	# dz1=dRelu(zh)
	dw1 = np.dot(X.T, dz1 * dh1)+(beta*w1)
	db1 = np.sum(dh1 * dz1,axis=0)
	nabla = (db1, dw1,db2,dw2)


	return nabla
    ############################################################################

