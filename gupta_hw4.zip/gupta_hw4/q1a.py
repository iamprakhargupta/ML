"""
FileName: q1a.py
Author: prakhar gupta_hw4 pg9349
Description: Create a multinomial MLP model for XOR
"""


import matplotlib.pyplot as plt
import os
import numpy as np
import pandas as pd
from helper_functions import *

"""
0.004443493661832224
"""

# beta = 1e-4 # regularization coefficient
beta = 0 # regularization coefficient
alpha = 0.1  # step size coefficient
n_epoch = 5000 # number of epochs (full passes through the dataset)
eps =  0.00000# controls convergence criterion

# begin simulation

path = os.getcwd() + '/xor.dat'
data2 = pd.read_csv(path, header=None)
X=data2.to_numpy()

cols = data2.shape[1]
X2 = data2.iloc[:,0:-1]
y2 = data2.iloc[:,-1]
y3=y2.values
y3=np.vstack(y3)
y2=pd.get_dummies(y2)
np.random.seed(1)
# convert to numpy arrays and initalize the parameter array theta
X2 = np.array(X2.values)
y2 = np.array(y2.values)

# # Uncomment for zero intialization
# w = np.zeros((X2.shape[1],y2.shape[1]))


instances = X2.shape[0]
attributes = X2.shape[1]
hidden_nodes = 3
output_labels = 2

w1 = np.random.rand(attributes,hidden_nodes)
b1 = np.random.randn(hidden_nodes)

w2 = np.random.rand(hidden_nodes,output_labels)
b2 = np.random.randn(output_labels)

theta2 = (b1, w1,b2,w2)

L = computeCost(X2, y2, theta2, beta)

# print(X2)
print(w1)
print("_________")
print(w2)

"""
Loss function value:  9.20387390375952
Loss function value:  9.20387390375952
Loss function value:  7.784967766894681
Loss function value:  6.465799472449794
Loss function value:  5.287446860417562
"""


halt = np.inf # halting variable (you can use these to terminate the loop if you have converged)
print("-1 L = {0}".format(L))


print("_____________________________________________________")
print("Gradient Checking Start")

#
# #
# # """
# Gradient checking
# Coding derivatives using limits proof
#
# """
#
delta=1e-4
w = np.zeros((X2.shape[1],y2.shape[1]))
# w=w1
b = np.zeros((1,y2.shape[1]))


w1 = np.zeros((attributes,hidden_nodes))
b1 = np.zeros((1,hidden_nodes))

w2 = np.zeros((hidden_nodes,output_labels))
b2 = np.zeros((1,output_labels))

secant_derivative_bias1=np.zeros(b1.shape)
secant_derivative_weights1=np.zeros(w1.shape)
secant_derivative_bias2=np.zeros(b2.shape)
secant_derivative_weights2=np.zeros(w2.shape)

originalw1=w1
originalb1=b1
originalw2=w2
originalb2=b2

theta = (b1, w1,b2,w2)
dcost_bh, dcost_wh,dcost_bo,dcost_wo = computeGrad(X2, y2, theta, beta)
# theta = (b, w)
print("_____________________________________________________")
print("Checking for derivatives i.e bias")
for x, y in np.ndindex(b1.shape):
	b1 = originalb1
	b1[x,y]=b1[x,y]-delta
	theta = (b1, w1,b2,w2)
	term1=computeCost(X2, y2, theta, beta)
	b1=originalb1
	b1[x,y]=b1[x,y]+delta
	theta = (b1, w1,b2,w2)
	term2=computeCost(X2, y2, theta, beta)
	final=(term2-term1)/(delta*2)
	secant_derivative_bias1[x,y]=final
	# np.insert(secant_derivative_bias,(x,y), final)
# print(secant_derivative_bias)
# print(dL_db)
print("_____________________________________________________")
print("Individual biases 1 hidden layer")
extra=abs(secant_derivative_bias1-dcost_bh)<=1e-4
extra=extra.tolist()
for i in extra:
	for j in i:
		if j==True:
			print("CORRECT",end=" ")
		else:
			print(j,end=" ")
	print()
# print(abs(secant_derivative_bias-dL_db)<=1e-4)
if (abs(secant_derivative_bias1-dcost_bh)<=1e-4).all():
	print("Bias Derivative for hidden Correct")

for x, y in np.ndindex(b2.shape):
	b2 = originalb2
	b2[x,y]=b2[x,y]-delta
	theta = (b1, w1,b2,w2)
	term1=computeCost(X2, y2, theta, beta)
	b2=originalb2
	b2[x,y]=b2[x,y]+delta
	theta = (b1, w1,b2,w2)
	term2=computeCost(X2, y2, theta, beta)
	final=(term2-term1)/(delta*2)
	secant_derivative_bias2[x,y]=final
	# np.insert(secant_derivative_bias,(x,y), final)
# print(secant_derivative_bias)
# print(dL_db)
print("_____________________________________________________")
print("Individual biases 2 output layer")
extra=abs(secant_derivative_bias2-dcost_bo)<=1e-4
extra=extra.tolist()
for i in extra:
	for j in i:
		if j==True:
			print("CORRECT",end=" ")
		else:
			print(j,end=" ")
	print()
# print(abs(secant_derivative_bias-dL_db)<=1e-4)
if (abs(secant_derivative_bias1-dcost_bh)<=1e-4).all():
	print("Bias Derivative for output Correct")



print("_____________________________________________________")
print("Checking for derivatives i.e weights")

for x, y in np.ndindex(w1.shape):
	w1 = originalw1
	w1[x,y]=w1[x,y]-delta
	theta = (b1, w1,b2,w2)
	term1=computeCost(X2, y2, theta, beta)
	w1=originalw1
	w1[x,y]=w1[x,y]+delta
	theta = (b1, w1,b2,w2)
	term2=computeCost(X2, y2, theta, beta)
	final=(term2-term1)/(delta*2)
	secant_derivative_weights1[x,y]=final
	# np.insert(secant_derivative_bias,(x,y), final)
# print(secant_derivative_weights)
# print(dL_dw)
print("_____________________________________________________")
print("Individual Weights for 1 layer hidden layer")

extra=abs(secant_derivative_weights1-dcost_wh)<=1e-4
extra=extra.tolist()
for i in extra:
	for j in i:
		if j==True:
			print("CORRECT",end=" ")
		else:
			print(j,end=" ")
	print()

if (abs(secant_derivative_weights1-dcost_wh)<=1e-4).all():
	print("Weights Derivative Correct for hidden layer")



for x, y in np.ndindex(w2.shape):
	w2 = originalw2
	w2[x,y]=w2[x,y]-delta
	theta = (b1, w1,b2,w2)
	term1=computeCost(X2, y2, theta, beta)
	w2=originalw2
	w2[x,y]=w2[x,y]+delta
	theta = (b1, w1,b2,w2)
	term2=computeCost(X2, y2, theta, beta)
	final=(term2-term1)/(delta*2)
	secant_derivative_weights2[x,y]=final
	# np.insert(secant_derivative_bias,(x,y), final)
# print(secant_derivative_weights)
# print(dL_dw)
print("_____________________________________________________")
print("Individual Weights for 2 layer output layer")

extra=abs(secant_derivative_weights2-dcost_wo)<=1e-4
extra=extra.tolist()
for i in extra:
	for j in i:
		if j==True:
			print("CORRECT",end=" ")
		else:
			print(j,end=" ")
	print()

if (abs(secant_derivative_weights1-dcost_wh)<=1e-4).all():
	print("Weights Derivative Correct for output layer")


print("_____________________________________________________")
print("Training this model now")

i = 0
cost=[]
cost.append(L)
while(i < n_epoch):
	dcost_bh, dcost_wh,dcost_bo,dcost_wo = computeGrad(X2, y2, theta2, beta)
	b1 = theta2[0]
	w1 = theta2[1]
	b2 = theta2[2]
	w2 = theta2[3]


    ############################################################################
	# update rules go here...
	# WRITEME: write your code here to perform a step of gradient descent & record anything else desired for later
    ############################################################################
	b1 -= alpha*dcost_bh
	w1 -= alpha*dcost_wh
	b2 -= alpha*dcost_bo
	w2 -= alpha*dcost_wo

	# [[0.10553018 0.06522365 0.17797186]
	#  [0.30295888 0.36984919 0.53032177]]       ---  [1.63896302 - 0.81148934
	# 												 0.29971841]

	theta2 = (b1, w1,b2,w2)
	# print(w2)
	L = computeCost(X2, y2, theta2, beta)
	# print(w)
    ############################################################################
	# WRITEME: write code to perform a check for convergence (or simply to halt early)
    ############################################################################
	cost.append(L)
	if len(cost)>=2:
		halt = cost[-2]-cost[-1]
		# print(halt)

	print(" {0} L = {1}".format(i,L))
	i += 1
# print parameter values found after the search

# print("w = ",w)
# print("b = ",b)
halt = cost[-2]-cost[-1]
if  halt <=eps:
	print("Model initial epochs set at ",n_epoch)
	print("Convergence happened at epoch ",i-1)
############################################################################
predictions = predict(X2, theta2)
# print(predictions)
# print(predictions)
# WRITEME: write your code here calculate your actual classification error (using the "predictions" variable)
y3=np.argmax(y2,axis=1)
N = predictions.shape[0]
y=predictions

print("-------")
# print(predictions)
accuracy = (y3 == y).sum() / N
print('Accuracy = {0}%'.format(accuracy * 100.))
err = 1-accuracy
print ('Error = {0}%'.format(err * 100.))


plt.plot(cost, label='Training Loss')
plt.title("LOSS CURVE")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend(loc="upper right")
plt.savefig("Losscurveq1a.jpeg")
plt.show()


