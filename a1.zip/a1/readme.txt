The q1 code uses pandas numpy matplotlib and seaborn

The q2 code used pytorch 
I have set the random seed for result reproducibity while training Logistic regression model

I have also shared both jupyter notebooks and  .py files in case grader need to run 
the code cell wise 
